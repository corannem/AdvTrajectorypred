import os

import sys
sys.path.append('./')
from data.TrajectoryDataset import TrajectoryDataset
from utils.misc_utils import get_files, get_dirs


data_dir = 'data/collisions/'
tr_dir = os.path.join(data_dir, 'train')
val_dir = os.path.join(data_dir, 'validation')
te_dir = os.path.join(data_dir, 'test')

tr_data_files = [os.path.join(dirname, filename) for dirname in get_dirs(tr_dir) for filename in get_files(os.path.join(tr_dir, dirname))]
val_data_files = [os.path.join(dirname, filename) for dirname in get_dirs(val_dir) for filename in get_files(os.path.join(val_dir, dirname))]
te_data_files = [os.path.join(dirname, filename) for dirname in get_dirs(te_dir) for filename in get_files(os.path.join(te_dir, dirname))]

tr_data_files = [os.path.join(tr_dir, filepath) for filepath in tr_data_files]
val_data_files = [os.path.join(val_dir, filepath) for filepath in val_data_files]
te_data_files = [os.path.join(te_dir, filepath) for filepath in te_data_files]

def get_dataset(dtype, max_length=25, min_length=25, skip_frames=3, burn_in_steps=10, frame_shift=40, **kwargs):
    if dtype == 'tr':
        return TrajectoryDataset(tr_data_files, max_length=max_length, skip_frames=skip_frames,
                                 frame_shift=frame_shift, burn_in_steps=burn_in_steps, min_length=min_length, **kwargs)
    elif dtype == 'te':
        return TrajectoryDataset(te_data_files, max_length=max_length, skip_frames=skip_frames,
                                 frame_shift=frame_shift, burn_in_steps=burn_in_steps, min_length=min_length, **kwargs)
    elif dtype == 'val':
        return TrajectoryDataset(val_data_files, max_length=max_length, skip_frames=skip_frames,
                                 frame_shift=frame_shift, burn_in_steps=burn_in_steps, min_length=min_length, **kwargs)
